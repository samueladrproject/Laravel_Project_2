<?php $__env->startSection('content-wrapper'); ?>
    <section class="content pt-4">
        <h3 class="text-success"><i class="nav-icon fas fa-search-plus mr-1"></i> Hasil Konsultasi</h3>
        <hr>
        <div class="card">
            <div class="card-body">
                <div class="d-inline d-grid gap-2 d-md-flex justify-content-md-end mb-3">
                    <button class="btn btn-success" type="button" onclick="window.print();"><i class="fas fa-print me-1"></i>
                        Print</button>
                </div>
                <div class="card">
                    <div class="card-header bg-success">Detail Pasien</div>
                    <div class="card-body">
                        <table style="width: 100%;">
                            <colgroup>
                                <col span="1" style="width: 15%;">
                                <col span="1" style="width: 3%;">
                                <col span="1" style="width: 82%;">
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td class="fw-bold">Nama Pasien</td>
                                    <td>:</td>
                                    <td><?php echo e($dataPasien->nama_pasien); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Jenis Kelamin</td>
                                    <td>:</td>
                                    <td><?php echo e($dataPasien->jenis_kelamin); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Usia</td>
                                    <td>:</td>
                                    <td><?php echo e($dataPasien->usia); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($dataPasien->alamat); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">No.Handphone</td>
                                    <td>:</td>
                                    <td><?php echo e($dataPasien->no_handphone); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header bg-primary">Gejala yang dialami</div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead class="bg-primary">
                                <tr>
                                    <th>No.</th>
                                    <th>Kode Gejala</th>
                                    <th>Nama Gejala</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = json_decode($dataDiagnosa->nama_gejala); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gejala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($gejala->kode_gejala); ?></td>
                                        <td><?php echo e($gejala->nama_gejala); ?></td>
                                    </tr>

                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header bg-warning">Detail Penyakit</div>
                    <div class="card-body">
                        <p>
                            <b><?php echo e(json_decode($dataDiagnosa->hasil_diagnosa)->nama_penyakit); ?></b> /
                            <?php echo e(json_decode($dataDiagnosa->hasil_diagnosa)->persentase . ' %'); ?>

                            (<?php echo e(json_decode($dataDiagnosa->hasil_diagnosa)->probabilitas); ?>)
                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header bg-danger">Solusi Penyakit</div>
                    <div class="card-body"><?php echo e($dataDiagnosa->solusi); ?></div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samueladriel/Documents/My Project On 2022/Website/SP_CertaintyFactor_Project2/resources/views/frontend/pages/hasilkonsultasi.blade.php ENDPATH**/ ?>
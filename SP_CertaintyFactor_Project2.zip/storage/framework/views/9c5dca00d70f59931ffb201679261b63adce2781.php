<div class="sidebar">
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <img src="<?php echo e(URL::to('adminLTE/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2"
                alt="User Image">
        </div>
        <div class="info">
            <a href="<?php echo e(URL::to('dashboard')); ?>" class="d-block">Administrator</a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="<?php echo e(URL::to('dashboard')); ?>" class="nav-link <?php echo e($navLink == 'dashboard' ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-home"></i>
                    <p>
                        Dashboard
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(URL::to('data-penyakit')); ?>"
                    class="nav-link <?php echo e($navLink == 'data-penyakit' ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-bug"></i>
                    <p>
                        Data Penyakit
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(URL::to('data-gejala')); ?>"
                    class="nav-link <?php echo e($navLink == 'data-gejala' ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-vial"></i>
                    <p>
                        Data Gejala
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(URL::to('data-aturan')); ?>"
                    class="nav-link <?php echo e($navLink == 'data-aturan' ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-recycle"></i>
                    <p>
                        Data Aturan
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(URl::to('data-riwayat')); ?>"
                    class="nav-link <?php echo e($navLink == 'data-riwayat' ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-history"></i>
                    <p>
                        Data Riwayat
                    </p>
                </a>
            </li>
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<?php /**PATH /home/samueladriel/Documents/My Project On 2022/Website/SP_CertaintyFactor_Project2/resources/views/backend/partials/sidebar.blade.php ENDPATH**/ ?>
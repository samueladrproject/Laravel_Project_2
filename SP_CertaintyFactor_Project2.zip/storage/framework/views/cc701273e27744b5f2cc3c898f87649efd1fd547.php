<div class="sidebar">
    

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="<?php echo e(URL::to('/')); ?>" class="nav-link active">
                    <i class="nav-icon fas fa-home"></i>
                    <p>
                        Home
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(URL::to('/konsultasi')); ?>" class="nav-link">
                    <i class="nav-icon fas fa-search-plus"></i>
                    <p>
                        Konsultasi
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-book"></i>
                    <p>
                        Informasi Penyakit
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-info-circle"></i>
                    <p>
                        Tentang
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-question-circle"></i>
                    <p>
                        Bantuan
                    </p>
                </a>
            </li>
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<?php /**PATH /home/adry2296/public_html/certaintyfactor-project2_core/resources/views/frontend/partials/sidebar.blade.php ENDPATH**/ ?>
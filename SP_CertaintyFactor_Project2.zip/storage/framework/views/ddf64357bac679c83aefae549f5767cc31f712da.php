<?php $__env->startSection('content-wrapper'); ?>
    <section class="content pt-4">
        <!-- Default box -->
        <div class="card">
            <div class="card-body">
                <h3 class="text-success"><i class="fas fa-search-plus mr-1"></i> Konsultasi Penyakit</h3>
                <hr>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <div>
                        <p class="m-0 p-0 text-white">
                            Silahkan memilih gejala sesuai dengan kondisi anda. Jika sudah memilih gejala, tekan tombol
                            submit data yang ada dibawah untuk melihat hasil.
                        </p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(URL::to('/konsultasi')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered table-noquery mb-3" style="border-bottom: 0;">
                        <thead class="bg-success">
                            <tr class="text-center">
                                <th>No</th>
                                <th>Kode</th>
                                <th>Gejala</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $dataGejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gejala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($i); ?></td>
                                    <td class="text-center"><?php echo e($gejala['kode_gejala']); ?></td>
                                    <td><?php echo e($gejala['nama_gejala']); ?></td>
                                    <td class="text-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="choiceRadio[]"
                                                value="<?php echo e($gejala['nama_gejala']); ?>">
                                        </div>
                                    </td>
                                </tr>
                                <?php
                                    $i++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button class="btn btn-success me-md-2" type="submit">
                            <i class="fas fa-save mr-1"></i>
                            Submit Data
                        </button>
                        <button class="btn btn-secondary" type="reset">
                            <i class="fas fa-ban"></i>
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!-- /.card -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adry2296/public_html/certaintyfactor-project2_core/resources/views/frontend/pages/konsultasi.blade.php ENDPATH**/ ?>
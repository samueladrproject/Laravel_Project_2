<?php $__env->startSection('content-wrapper'); ?>
    <section class="content pt-4">
        <!-- Default box -->
        <div class="card">
            <img src="<?php echo e(URL::to('assets/img/home.jpg')); ?>" class="card-img-top mb-3" alt="...">
            <div class="card-body text-center">
                <a class="btn btn-warning text-white mb-3" href="<?php echo e(URL::to('konsultasi')); ?>">
                    <i class="fas fa-search-plus"></i>
                    Mulai Konsultasi
                </a>
            </div>
        </div>
        <!-- /.card -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samueladriel/Documents/My Project On 2022/Website/SP_CertaintyFactor_Project2/resources/views/frontend/pages/home.blade.php ENDPATH**/ ?>
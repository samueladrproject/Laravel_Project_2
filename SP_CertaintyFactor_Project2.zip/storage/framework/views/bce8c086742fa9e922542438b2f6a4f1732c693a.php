
<?php /**PATH C:\Users\Hewlett-Packard\Documents\Samuel Project's 2022\Developments\Laravel\sp-erry\resources\views/auth/login.blade.php ENDPATH**/ ?>